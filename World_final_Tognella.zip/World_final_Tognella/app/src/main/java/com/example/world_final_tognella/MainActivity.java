package com.example.world_final_tognella;


import android.app.Activity;
import android.graphics.Color;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    // Creazione di una variabile per l'activity binding.
    private ActivityMainBinding binding;

    // Creazione di una variabile per la parola da indovinare.
    private final String WORD = "house";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        binding = ActivityMainBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        // Chiamata del metodo per passare il focus al prossimo EditText.
        keepPassingFocus();

        // Aggiunta di un listener per il cambio di testo
        // per l'ultimo EditText di ogni riga.
        binding.edt_15.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {
            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
            }

            @Override
            public void afterTextChanged(Editable s) {
                if (s != null && s.length() == 1) {
                    validateRow(binding.edt_11, binding.edt_12, binding.edt_13, binding.edt_14, binding.edt_15);
                }
                if(s != null && s.length() == 2) {
                    validateRow(binding.edt_21, binding.edt_22, binding.edt_23, binding.edt_24, binding.edt_25);
                }
                if(s != null && s.length() == 3) {
                    validateRow(binding.edt_31, binding.edt_32, binding.edt_33, binding.edt_34, binding.edt_35);
                }
                if(s != null && s.length() == 4) {
                    validateRow(binding.edt_41, binding.edt_42, binding.edt_43, binding.edt_44, binding.edt_45);
                }
                if(s != null && s.length() == 5) {
                    validateRow(binding.edt_51, binding.edt_52, binding.edt_53, binding.edt_54, binding.edt_55);
                }
                if(s != null && s.length() == 6) {
                    validateRow(binding.edt_61, binding.edt_62, binding.edt_63, binding.edt_64, binding.edt_65);
                }
            }
        });
    }

    private void makeGameInactive() {
        // Disabilita tutti gli EditText per rendere il gioco inattivo.
        binding.edt_11.setEnabled(false);
        binding.edt_12.setEnabled(false);
        binding.edt_13.setEnabled(false);
        binding.edt_14.setEnabled(false);
        binding.edt_15.setEnabled(false);
        binding.edt_21.setEnabled(false);
        binding.edt_22.setEnabled(false);
        binding.edt_23.setEnabled(false);
        binding.edt_24.setEnabled(false);
        binding.edt_25.setEnabled(false);
        binding.edt_31.setEnabled(false);
        binding.edt_32.setEnabled(false);
        binding.edt_33.setEnabled(false);
        binding.edt_34.setEnabled(false);
        binding.edt_35.setEnabled(false);
        binding.edt_41.setEnabled(false);
        binding.edt_42.setEnabled(false);
        binding.edt_43.setEnabled(false);
        binding.edt_44.setEnabled(false);
        binding.edt_45.setEnabled(false);
        binding.edt_51.setEnabled(false);
        binding.edt_52.setEnabled(false);
        binding.edt_53.setEnabled(false);
        binding.edt_54.setEnabled(false);
        binding.edt_61.setEnabled(false);
        binding.edt_62.setEnabled(false);
        binding.edt_63.setEnabled(false);
        binding.edt_64.setEnabled(false);
        binding.edt_65.setEnabled(false);
    }

    private void validateRow(EditText edt1, EditText edt2, EditText edt3, EditText edt4, EditText edt5) {
        // Ottenere il testo dagli EditText.
        String edt1Txt = edt1.getText().toString();
        String edt2Txt = edt2.getText().toString();
        String edt3Txt = edt3.getText().toString();
        String edt4Txt = edt4.getText().toString();
        String edt5Txt = edt5.getText().toString();

        // Ottenere ogni carattere dalla parola.
        String w1 = String.valueOf(WORD.charAt(0));
        String w2 = String.valueOf(WORD.charAt(1));
        String w3 = String.valueOf(WORD.charAt(2));
        String w4 = String.valueOf(WORD.charAt(3));
        String w5 = String.valueOf(WORD.charAt(4));

        // Compara le parole inserite con quella da indovinare, cambiandone il colore della casella se corrette
        if (edt1Txt.equals(w2) || edt1Txt.equals(w3)  || edt1Txt.equals(w4) || edt1Txt.equals(w5)) {
            edt1.setBackgroundColor(Color.parseColor("#ffff00"));
        }
        if (edt1Txt.equals(w2) || edt1Txt.equals(w3)  || edt1Txt.equals(w4) || edt1Txt.equals(w5)) {
            edt2.setBackgroundColor(Color.parseColor("#ffff00"));
        }
        if (edt1Txt.equals(w2) || edt1Txt.equals(w3)  || edt1Txt.equals(w4) || edt1Txt.equals(w5)) {
            edt3.setBackgroundColor(Color.parseColor("#ffff00"));
        }
        if (edt1Txt.equals(w2) || edt1Txt.equals(w3)  || edt1Txt.equals(w4) || edt1Txt.equals(w5)) {
            edt4.setBackgroundColor(Color.parseColor("#ffff00"));
        }
        if (edt1Txt.equals(w2) || edt1Txt.equals(w3)  || edt1Txt.equals(w4) || edt1Txt.equals(w5)) {
            edt5.setBackgroundColor(Color.parseColor("#ffff00"));
        }

        // Compara le lettere inserite con la parola da indovinare, cambiandone il colore della casella se presente
        if (edt1Txt.equals(w1)) {
            edt1.setBackgroundColor(Color.parseColor("#33cc33"));
        }
        if (edt2Txt.equals(w2)) {
            edt2.setBackgroundColor(Color.parseColor("#33cc33"));
        }
        if (edt3Txt.equals(w3)) {
            edt3.setBackgroundColor(Color.parseColor("#33cc33"));
        }
        if (edt4Txt.equals(w4)) {
            edt4.setBackgroundColor(Color.parseColor("#33cc33"));
        }
        if (edt5Txt.equals(w5)) {
            edt5.setBackgroundColor(Color.parseColor("#33cc33"));
        }

        // Compara le parole inserite con quella da indovinare, cambiandone il colore della casella se non è presente
        if (edt1Txt != w1 && edt1Txt != w2 && edt1Txt != w3 && edt1Txt != w4 && edt1Txt != w5) {
            edt1.setBackgroundColor(Color.parseColor("#ff3333"));
        }
        if (edt2Txt != w1 && edt2Txt != w2 && edt2Txt != w3 && edt2Txt != w4 && edt2Txt != w5) {
            edt2.setBackgroundColor(Color.parseColor("#ff3333"));
        }
        if (edt3Txt != w1 && edt3Txt != w2 && edt3Txt != w3 && edt3Txt != w4 && edt3Txt != w5) {
            edt3.setBackgroundColor(Color.parseColor("#ff3333"));
        }
        if (edt4Txt != w1 && edt4Txt != w2 && edt4Txt != w3 && edt4Txt != w4 && edt4Txt != w5) {
            edt4.setBackgroundColor(Color.parseColor("#ff3333"));
        }
        if (edt5Txt != w1 && edt5Txt != w2 && edt5Txt != w3 && edt5Txt != w4 && edt5Txt != w5) {
            edt5.setBackgroundColor(Color.parseColor("#ff3333"));
        }

        // Verifica se la parola è stata indovinata.
        if (edt1Txt.equals(w1) && edt2Txt.equals(w2) && edt3Txt.equals(w3)
                && edt4Txt.equals(w4) && edt5Txt.equals(w5)) {
            binding.idResult.setText("Congratulazioni, hai indovinato la parola giusta.");
            binding.idResult.setVisibility(View.VISIBLE);
            makeGameInactive();
            Toast.makeText(
                    getApplicationContext(),
                    "Congratulazioni, hai indovinato la parola giusta.",
                    Toast.LENGTH_SHORT
            ).show();
            return;
        }

        // Verifica se l'utente è riuscito a indovinare la parola.
        if (edt5.getId() == R.id.edt_65) {
            binding.idResult.setText("Spiacente, non hai indovinato la parola.");
            binding.idResult.setVisibility(View.VISIBLE);
            makeGameInactive();
            Toast.makeText(
                    getApplicationContext(),
                    "Spiacente, non hai indovinato la parola.",
                    Toast.LENGTH_SHORT
            ).show();
        }
    }

    private void keepPassingFocus() {
        // Passare il focus al successivo EditText se quello precedente è stato compilato.
        //riga 1
        passFocusToNextEdt(binding.edt_11, binding.edt_12);
        passFocusToNextEdt(binding.edt_12, binding.edt_13);
        passFocusToNextEdt(binding.edt_13, binding.edt_14);
        passFocusToNextEdt(binding.edt_14, binding.edt_15);

        //riga 2
        passFocusToNextEdt(binding.edt_21, binding.edt_22);
        passFocusToNextEdt(binding.edt_22, binding.edt_23);
        passFocusToNextEdt(binding.edt_23, binding.edt_24);
        passFocusToNextEdt(binding.edt_24, binding.edt_25);

        //riga 3
        passFocusToNextEdt(binding.edt_31, binding.edt_32);
        passFocusToNextEdt(binding.edt_32, binding.edt_33);
        passFocusToNextEdt(binding.edt_33, binding.edt_34);
        passFocusToNextEdt(binding.edt_34, binding.edt_35);

        //riga4
        passFocusToNextEdt(binding.edt_41, binding.edt_42);
        passFocusToNextEdt(binding.edt_42, binding.edt_43);
        passFocusToNextEdt(binding.edt_43, binding.edt_44);
        passFocusToNextEdt(binding.edt_44, binding.edt_45);

        //riga 5
        passFocusToNextEdt(binding.edt_51, binding.edt_52);
        passFocusToNextEdt(binding.edt_52, binding.edt_53);
        passFocusToNextEdt(binding.edt_53, binding.edt_54);
        passFocusToNextEdt(binding.edt_54, binding.edt_55);

        //riga 6
        passFocusToNextEdt(binding.edt_61, binding.edt_62);
        passFocusToNextEdt(binding.edt_62, binding.edt_63);
        passFocusToNextEdt(binding.edt_63, binding.edt_64);
        passFocusToNextEdt(binding.edt_64, binding.edt_65);
    }

    private void passFocusToNextEdt(EditText edt1, EditText edt2) {
        // Passare il focus al successivo EditText se quello corrente è stato compilato.
        edt1.addTextChangedListener(new TextWatcher() {
            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
            }

            @Override
            public void afterTextChanged(Editable s) {
                if (s != null && s.length() == 1) {
                    edt2.requestFocus();
                }
            }
        });
    }
}